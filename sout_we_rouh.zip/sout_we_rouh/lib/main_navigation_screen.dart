import 'package:flutter/material.dart';

class TalentModel {
  final String name;
  final String category;
  final String bio;
  final String phone;
  final String email;
  bool isApproved;

  TalentModel({
    required this.name,
    required this.category,
    required this.bio,
    required this.phone,
    this.email = '', // جعلناه اختيارياً بقيمة افتراضية لكي لا يحدث أي خطأ
    this.isApproved = false,
  });
}

List<TalentModel> registeredTalents = [];

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  int _currentIndex = 5;

  final List<Widget> _screens = const [
    SingingScreen(),
    PoetryScreen(),
    ComposingScreen(),
    ArtistsScreen(),
    GuideScreen(),
    AccountScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: const Color(0xFF7B1FA2),
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.mic), label: 'الغناء'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'الشعر'),
          BottomNavigationBarItem(icon: Icon(Icons.music_note), label: 'التلحين'),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'الفنانين'),
          BottomNavigationBarItem(icon: Icon(Icons.menu_book), label: 'الدليل'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'حسابي'),
        ],
      ),
    );
  }
}

PreferredSizeWidget customAppBar(String titleText) {
  return AppBar(
    title: Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: Image.asset(
            'assets/logo.png',
            width: 40,
            height: 40,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => const Icon(Icons.star, color: Colors.white, size: 30),
          ),
        ),
        const SizedBox(width: 12),
        Text(titleText, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ],
    ),
    backgroundColor: const Color(0xFF7B1FA2),
    iconTheme: const IconThemeData(color: Colors.white),
    elevation: 2,
  );
}

class TalentDetailScreen extends StatelessWidget {
  final TalentModel talent;
  final IconData icon;

  const TalentDetailScreen({super.key, required this.talent, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar(talent.name),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            CircleAvatar(
              radius: 50,
              backgroundColor: const Color(0xFF7B1FA2).withOpacity(0.1),
              child: Icon(icon, size: 50, color: const Color(0xFF7B1FA2)),
            ),
            const SizedBox(height: 20),
            Text(
              talent.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.purple.shade100),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('نبذة عن الموهبة / العمل:', style: TextStyle(fontWeight: FontWeight.bold, color: Color(0xFF7B1FA2))),
                  const SizedBox(height: 8),
                  Text(talent.bio, style: const TextStyle(fontSize: 16, color: Colors.black87)),
                  const SizedBox(height: 12),
                  Text('القسم: ${talent.category}', style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SingingScreen extends StatelessWidget {
  const SingingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var singingList = registeredTalents.where((t) => t.category == 'غناء' && t.isApproved).toList();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('مواهب الغناء 🎤'),
      body: singingList.isEmpty
          ? const Center(child: Text('لا توجد مواهب غناء مفعلة حتى الآن', style: TextStyle(color: Colors.black54, fontSize: 16)))
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: singingList.length,
              itemBuilder: (context, index) {
                var talent = singingList[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TalentDetailScreen(talent: talent, icon: Icons.mic)));
                  },
                  child: Card(
                    elevation: 2,
                    color: Colors.white,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: const Icon(Icons.mic, color: Color(0xFF7B1FA2)),
                      title: Text(talent.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(talent.bio, maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class PoetryScreen extends StatelessWidget {
  const PoetryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var poetryList = registeredTalents.where((t) => t.category == 'شعر' && t.isApproved).toList();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('مواهب الشعر 📜'),
      body: poetryList.isEmpty
          ? const Center(child: Text('لا توجد مواهب شعر مفعلة حتى الآن', style: TextStyle(color: Colors.black54, fontSize: 16)))
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: poetryList.length,
              itemBuilder: (context, index) {
                var talent = poetryList[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TalentDetailScreen(talent: talent, icon: Icons.book)));
                  },
                  child: Card(
                    elevation: 2,
                    color: Colors.white,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: const Icon(Icons.book, color: Color(0xFF7B1FA2)),
                      title: Text(talent.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(talent.bio, maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class ComposingScreen extends StatelessWidget {
  const ComposingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var composingList = registeredTalents.where((t) => t.category == 'تلحين' && t.isApproved).toList();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('مواهب التلحين 🎼'),
      body: composingList.isEmpty
          ? const Center(child: Text('لا توجد مواهب تلحين مفعلة حتى الآن', style: TextStyle(color: Colors.black54, fontSize: 16)))
          : ListView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: composingList.length,
              itemBuilder: (context, index) {
                var talent = composingList[index];
                return InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => TalentDetailScreen(talent: talent, icon: Icons.music_note)));
                  },
                  child: Card(
                    elevation: 2,
                    color: Colors.white,
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: const Icon(Icons.music_note, color: Color(0xFF7B1FA2)),
                      title: Text(talent.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(talent.bio, maxLines: 1, overflow: TextOverflow.ellipsis),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class ArtistsScreen extends StatelessWidget {
  const ArtistsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('الفنانين المعروفين ⭐'),
      body: const Center(
        child: Text('لا توجد مواهب مفعلة في هذا القسم حالياً', style: TextStyle(color: Colors.black54, fontSize: 16)),
      ),
    );
  }
}

class GuideScreen extends StatelessWidget {
  const GuideScreen({super.key});

  @override
  Widget build(BuildContext context) {
    var approvedList = registeredTalents.where((t) => t.isApproved).toList();
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('دليل كل المواهب 📖'),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const TextField(
            decoration: InputDecoration(
              hintText: 'ابحث عن اسم موهبة أو عمل...',
              prefixIcon: Icon(Icons.search),
              border: OutlineInputBorder(),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
          const SizedBox(height: 12),
          approvedList.isEmpty
              ? const Padding(
                  padding: EdgeInsets.only(top: 50.0),
                  child: Center(child: Text('الدليل فارغ حالياً، بانتظار تفعيل المواهب', style: TextStyle(color: Colors.black54))),
                )
              : Column(
                  children: approvedList.map((talent) => Card(
                    color: Colors.white,
                    child: ListTile(
                      title: Text(talent.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text(talent.bio),
                      trailing: Text(talent.category, style: const TextStyle(color: Color(0xFF7B1FA2), fontWeight: FontWeight.bold)),
                    ),
                  )).toList(),
                ),
        ],
      ),
    );
  }
}

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: customAppBar('حسابي والأدمن 👤'),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const CircleAvatar(radius: 40, backgroundColor: Color(0xFF7B1FA2), child: Icon(Icons.admin_panel_settings, size: 40, color: Colors.white)),
            const SizedBox(height: 10),
            const Text('مي محمود (أدمن التطبيق 👑)', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.black87)),
            const Text('hayamahmoud049@gmail.com', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerRight,
              child: Text('طلبات الاشتراك والتحقق من الدفع (للأدمن فقط):', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black87)),
            ),
            const Divider(color: Colors.grey),
            Expanded(
              child: registeredTalents.isEmpty
                  ? const Center(child: Text('لا توجد أي طلبات اشتراك مسجلة حتى الآن', style: TextStyle(color: Colors.black54)))
                  : ListView.builder(
                      itemCount: registeredTalents.length,
                      itemBuilder: (context, index) {
                        var talent = registeredTalents[index];
                        return Card(
                          elevation: 2,
                          color: Colors.white,
                          margin: const EdgeInsets.only(bottom: 10),
                          child: ListTile(
                            title: Text(talent.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 4),
                                Text('القسم: ${talent.category}'),
                                if (talent.email.isNotEmpty)
                                  Text('البريد: ${talent.email}', style: const TextStyle(color: Colors.grey)),
                                Text('الهاتف المحول منه: ${talent.phone}', style: const TextStyle(color: Color(0xFF7B1FA2), fontWeight: FontWeight.bold)),
                                Text('الحالة: ${talent.isApproved ? "مفعل ✅" : "قيد المراجعة للتحقق من الدفع ⏳"}', 
                                  style: TextStyle(color: talent.isApproved ? Colors.green : Colors.orange, fontWeight: FontWeight.bold)),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (!talent.isApproved)
                                  IconButton(
                                    icon: const Icon(Icons.check_circle, color: Colors.green),
                                    tooltip: 'تفعيل الموهبة',
                                    onPressed: () {
                                      setState(() {
                                        talent.isApproved = true;
                                      });
                                    },
                                  ),
                                IconButton(
                                  icon: const Icon(Icons.delete, color: Colors.red),
                                  tooltip: 'حذف الطلب',
                                  onPressed: () {
                                    setState(() {
                                      registeredTalents.removeAt(index);
                                    });
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}