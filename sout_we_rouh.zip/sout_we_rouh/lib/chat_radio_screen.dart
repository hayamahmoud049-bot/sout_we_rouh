import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:cloud_firestore/cloud_firestore.dart';

class ChatRadioScreen extends StatefulWidget {
  final bool isSubscribed; 
  const ChatRadioScreen({super.key, this.isSubscribed = true});

  @override
  State<ChatRadioScreen> createState() => _ChatRadioScreenState();
}

class _ChatRadioScreenState extends State<ChatRadioScreen> {
  late final AudioPlayer _player;
  bool _isPlaying = false;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // القائمة الجديدة بالترتيب المظبوط:
  final List<Map<String, String>> _playlist = [
    {"title": "Dol-Mish-Habayeb", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Dol-Mish-Habayeb.mp3"},
    {"title": "Mai_Mahmoud_Ana_El_Motayyam", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Ana_El_Motayyam.mp3"},
    {"title": "Habayeb_Eh", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Habayeb_Eh.mp3"},
    {"title": "Mai_Mahmoud_Day_El_Qamar", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Day_El_Qamar.mp3"},
    {"title": "lakayetk", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/lakayetk.mp3"},
    {"title": "Mai_Mahmoud_Bakam_Thamani", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Bakam_Thamani.mp3"},
    {"title": "Oddam_El_Nas", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Oddam_El_Nas.mp3"},
    {"title": "Mai_Mahmoud_Hafez_El_Rouh", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Hafez_El_Rouh.mp3"},
    {"title": "algay_btaay", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/algay_btaay.mp3"},
    {"title": "set_elnas", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/set_elnas.mp3"},
    {"title": "Mai_Mahmoud_Sir_El_Hawa", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Sir_El_Hawa.mp3"},
    {"title": "Nesyanak Sa3b Akid", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Nesyanak%20Sa3b%20Akid.mp3"},
    {"title": "atakhr_atabna", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/atakhr_atabna.mp3"},
    {"title": "halwanhm", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/halwanhm.mp3"},
    {"title": "Mai_Mahmoud_Khayan", "url": "https://github.com/hayamahmoud049-bot/sout_we_rouh/raw/refs/heads/main/Mai_Mahmoud_Khayan.mp3"},
  ];
  
  int _currentSongIndex = 0;

  final List<Map<String, String>> _members = [
    {"name": "أحمد محمد", "status": "موهبة شعر"},
    {"name": "سارة علي", "status": "تلحين وعزف"},
    {"name": "محمود حسن", "status": "غناء طربي"},
    {"name": "ريم أحمد", "status": "مستمع مميز"},
  ];

  final TextEditingController _messageController = TextEditingController();

  final List<String> _activeChatWindows = [];
  final Map<String, List<Map<String, dynamic>>> _privateChats = {};
  final Map<String, Offset> _windowPositions = {};
  final Map<String, bool> _minimizedWindows = {};
  
  final List<Map<String, String>> _inboxMessages = [
    {"sender": "سارة علي", "text": "مرحباً مي، هل يمكنك الاستماع للحن الجديد؟"}
  ];

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _player = AudioPlayer();
    _initAudio();
  }

  Future<void> _initAudio() async {
    try {
      await _player.setUrl(_playlist[_currentSongIndex]["url"]!);
    } catch (e) {
      debugPrint("خطأ في تحميل الأغنية من الرابط: $e");
    }
  }

  @override
  void dispose() {
    _player.dispose();
    _messageController.dispose();
    super.dispose();
  }

  void _playNext() {
    setState(() {
      _currentSongIndex = (_currentSongIndex + 1) % _playlist.length;
    });
    _player.setUrl(_playlist[_currentSongIndex]["url"]!);
    if (_isPlaying) _player.play();
  }

  void _playPrevious() {
    setState(() {
      _currentSongIndex = (_currentSongIndex - 1 + _playlist.length) % _playlist.length;
    });
    _player.setUrl(_playlist[_currentSongIndex]["url"]!);
    if (_isPlaying) _player.play();
  }

  // دالة إرسال الرسالة إلى الـ Firestore في الشات العام
  void _sendPublicMessage() {
    if (_messageController.text.trim().isNotEmpty) {
      _firestore.collection('messages').add({
        "sender": "أنتِ",
        "text": _messageController.text,
        "isImage": false,
        "timestamp": FieldValue.serverTimestamp(),
      });
      _messageController.clear();
    }
  }

  void _openPrivateChat(String memberName) {
    if (!_activeChatWindows.contains(memberName)) {
      setState(() {
        _activeChatWindows.add(memberName);
        if (!_privateChats.containsKey(memberName)) {
          _privateChats[memberName] = [];
        }
        _windowPositions[memberName] = const Offset(80, 150);
        _minimizedWindows[memberName] = false;
      });
    } else {
      setState(() {
        _minimizedWindows[memberName] = false;
      });
    }
  }

  void _closePrivateChat(String memberName) {
    setState(() {
      _activeChatWindows.remove(memberName);
    });
  }

  void _toggleMinimizeChat(String memberName) {
    setState(() {
      _minimizedWindows[memberName] = !(_minimizedWindows[memberName] ?? false);
    });
  }

  void _openMessageFromInbox(Map<String, String> msg) {
    setState(() {
      _inboxMessages.remove(msg);
    });
    _openPrivateChat(msg["sender"]!);
  }

  Future<void> _pickAndSendImage(Function(String, bool) onImageSelected) async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      onImageSelected(image.path, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            children: [
              const Icon(Icons.mic_rounded, color: Colors.blueAccent, size: 24),
              const SizedBox(width: 8),
              const Text("راديو وشات صوت وروح (المشتركين)", style: TextStyle(color: Colors.white, fontSize: 18)),
            ],
          ),
          backgroundColor: Colors.purple.shade800,
          iconTheme: const IconThemeData(color: Colors.white),
          actions: [
            Stack(
              alignment: Alignment.center,
              children: [
                IconButton(
                  icon: const Icon(Icons.mail_outline, color: Colors.white, size: 26),
                  onPressed: () {
                    _showInboxDialog(context);
                  },
                ),
                if (_inboxMessages.isNotEmpty)
                  Positioned(
                    right: 8,
                    top: 8,
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: const BoxDecoration(
                        color: Colors.red,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        "${_inboxMessages.length}",
                        style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 10),
          ],
        ),
        body: Stack(
          children: [
            Column(
              children: [
                Container(
                  color: Colors.purple.shade50,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      const Icon(Icons.music_note, color: Colors.purple, size: 28),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _playlist[_currentSongIndex]["title"]!,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.purple),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_previous, color: Colors.purple, size: 28),
                        onPressed: _playPrevious,
                      ),
                      IconButton(
                        icon: Icon(
                          _isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled,
                          size: 38,
                          color: Colors.purple.shade800,
                        ),
                        onPressed: () async {
                          setState(() {
                            _isPlaying = !_isPlaying;
                          });
                          if (_isPlaying) {
                            await _player.play();
                          } else {
                            await _player.pause();
                          }
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_next, color: Colors.purple, size: 28),
                        onPressed: _playNext,
                      ),
                    ],
                  ),
                ),
                
                Expanded(
                  child: Row(
                    children: [
                      Container(
                        width: 250,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          border: Border(left: BorderSide(color: Colors.grey.shade300)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              color: Colors.purple.shade100,
                              child: const Row(
                                children: [
                                  Icon(Icons.people, color: Colors.purple, size: 20),
                                  SizedBox(width: 8),
                                  Text("قائمة الأعضاء والمواهب", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.purple, fontSize: 13)),
                                ],
                              ),
                            ),
                            Expanded(
                              child: ListView.builder(
                                itemCount: _members.length,
                                itemBuilder: (context, index) {
                                  final member = _members[index];
                                  return ListTile(
                                    leading: CircleAvatar(
                                      backgroundColor: Colors.purple.shade200,
                                      child: Text(member["name"]![0], style: const TextStyle(color: Colors.white)),
                                    ),
                                    title: Text(member["name"]!, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                    subtitle: Text(member["status"]!, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                                    trailing: const Icon(Icons.chat_bubble_outline, size: 16, color: Colors.purple),
                                    onTap: () {
                                      _openPrivateChat(member["name"]!);
                                    },
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),

                      Expanded(
                        child: Container(
                          color: Colors.grey.shade100,
                          child: Column(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                color: Colors.purple.shade50,
                                width: double.infinity,
                                child: const Text(
                                  "غرفة [ الشات العام ] - للمشتركين فقط",
                                  textAlign: TextAlign.center,
                                  style: TextStyle(fontSize: 12, color: Colors.purple, fontWeight: FontWeight.bold),
                                ),
                              ),
                              Expanded(
                                child: StreamBuilder<QuerySnapshot>(
                                  stream: _firestore.collection('messages').orderBy('timestamp', descending: true).snapshots(),
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState == ConnectionState.waiting) {
                                      return const Center(child: CircularProgressIndicator());
                                    }
                                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                                      return const Center(child: Text("لا توجد رسائل بعد، ابدأ المحادثة!"));
                                    }
                                    
                                    final docs = snapshot.data!.docs;

                                    return ListView.builder(
                                      reverse: true,
                                      padding: const EdgeInsets.all(12),
                                      itemCount: docs.length,
                                      itemBuilder: (context, index) {
                                        final msg = docs[index].data() as Map<String, dynamic>;
                                        final isMe = msg["sender"] == "أنتِ";
                                        return Align(
                                          alignment: isMe ? Alignment.centerLeft : Alignment.centerRight,
                                          child: Container(
                                            margin: const EdgeInsets.symmetric(vertical: 4),
                                            padding: const EdgeInsets.all(10),
                                            constraints: const BoxConstraints(maxWidth: 350),
                                            decoration: BoxDecoration(
                                              color: isMe ? Colors.purple.shade700 : Colors.white,
                                              borderRadius: BorderRadius.circular(12),
                                              boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 2)],
                                            ),
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Text(
                                                  msg["sender"] ?? "مجهول",
                                                  style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.bold,
                                                    color: isMe ? Colors.white70 : Colors.purple,
                                                  ),
                                                ),
                                                const SizedBox(height: 2),
                                                msg["isImage"] == true
                                                    ? (kIsWeb
                                                        ? Image.network(msg["text"], width: 150, height: 150, fit: BoxFit.cover)
                                                        : Image.file(File(msg["text"]), width: 150, height: 150, fit: BoxFit.cover))
                                                    : Text(
                                                        msg["text"] ?? "",
                                                        style: TextStyle(
                                                          fontSize: 13,
                                                          color: isMe ? Colors.white : Colors.black87,
                                                        ),
                                                      ),
                                              ],
                                            ),
                                          ),
                                        );
                                      },
                                    );
                                  },
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.all(8),
                                color: Colors.white,
                                child: Row(
                                  children: [
                                    IconButton(
                                      icon: const Icon(Icons.image, color: Colors.purple),
                                      onPressed: () async {
                                        await _pickAndSendImage((path, isImg) {
                                          _firestore.collection('messages').add({
                                            "sender": "أنتِ",
                                            "text": path,
                                            "isImage": isImg,
                                            "timestamp": FieldValue.serverTimestamp(),
                                          });
                                        });
                                      },
                                    ),
                                    Expanded(
                                      child: TextField(
                                        controller: _messageController,
                                        onSubmitted: (value) {
                                          _sendPublicMessage();
                                        },
                                        decoration: InputDecoration(
                                          hintText: "اكتب رسالة في الشات العام واضغط إنتر...",
                                          hintStyle: const TextStyle(fontSize: 12),
                                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
                                          filled: true,
                                          fillColor: Colors.grey.shade200,
                                          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    CircleAvatar(
                                      backgroundColor: Colors.purple,
                                      radius: 18,
                                      child: IconButton(
                                        icon: const Icon(Icons.send, color: Colors.white, size: 16),
                                        onPressed: _sendPublicMessage,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            ..._activeChatWindows.map((memberName) {
              final pos = _windowPositions[memberName] ?? const Offset(80, 150);
              final isMinimized = _minimizedWindows[memberName] ?? false;

              return Positioned(
                left: pos.dx,
                top: pos.dy,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onPanUpdate: (details) {
                    setState(() {
                      _windowPositions[memberName] = Offset(
                        pos.dx + details.delta.dx,
                        pos.dy + details.delta.dy,
                      );
                    });
                  },
                  child: Container(
                    width: 260,
                    height: isMinimized ? 40 : 300,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6)],
                      border: Border.all(color: Colors.purple.shade400),
                    ),
                    child: FloatingChatBox(
                      memberName: memberName,
                      messages: _privateChats[memberName]!,
                      isMinimized: isMinimized,
                      onClose: () => _closePrivateChat(memberName),
                      onMinimize: () => _toggleMinimizeChat(memberName),
                      onSend: (text, isImg) {
                        setState(() {
                          _privateChats[memberName]!.add({"sender": "أنتِ", "text": text, "isImage": isImg});
                        });
                      },
                      onPickImage: () async {
                        await _pickAndSendImage((path, isImg) {
                          setState(() {
                            _privateChats[memberName]!.add({"sender": "أنتِ", "text": path, "isImage": isImg});
                          });
                        });
                      },
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showInboxDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("صندوق البريد (الرسائل الخاصة)"),
          content: SizedBox(
            width: 300,
            height: 200,
            child: _inboxMessages.isEmpty
                ? const Center(child: Text("لا توجد رسائل جديدة"))
                : ListView.builder(
                    itemCount: _inboxMessages.length,
                    itemBuilder: (context, index) {
                      final msg = _inboxMessages[index];
                      return ListTile(
                        leading: const Icon(Icons.message, color: Colors.purple),
                        title: Text(msg["sender"]!, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        subtitle: Text(msg["text"]!, style: const TextStyle(fontSize: 12)),
                        onTap: () {
                          Navigator.pop(context);
                          _openMessageFromInbox(msg);
                        },
                      );
                    },
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("إغلاق"),
            ),
          ],
        );
      },
    );
  }
}

class FloatingChatBox extends StatefulWidget {
  final String memberName;
  final List<Map<String, dynamic>> messages;
  final bool isMinimized;
  final VoidCallback onClose;
  final VoidCallback onMinimize;
  final Function(String, bool) onSend;
  final Future<void> Function() onPickImage;

  const FloatingChatBox({
    super.key,
    required this.memberName,
    required this.messages,
    required this.isMinimized,
    required this.onClose,
    required this.onMinimize,
    required this.onSend,
    required this.onPickImage,
  });

  @override
  State<FloatingChatBox> createState() => _FloatingChatBoxState();
}

class _FloatingChatBoxState extends State<FloatingChatBox> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.purple.shade800,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
          ),
          child: Row(
            children: [
              const Icon(Icons.open_with, color: Colors.white70, size: 14),
              const SizedBox(width: 4),
              Expanded(
                child: Text(
                  widget.memberName,
                  style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              IconButton(
                icon: Icon(widget.isMinimized ? Icons.add : Icons.remove, color: Colors.white, size: 16),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: widget.onMinimize,
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 16),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
                onPressed: widget.onClose,
              ),
            ],
          ),
        ),
        if (!widget.isMinimized) ...[
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: widget.messages.length,
              itemBuilder: (context, index) {
                final msg = widget.messages[index];
                final isMe = msg["sender"] == "أنتِ";
                return Align(
                  alignment: isMe ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 2),
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: isMe ? Colors.purple.shade100 : Colors.grey.shade200,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: msg["isImage"] == true
                        ? (kIsWeb
                            ? Image.network(msg["text"], width: 100, height: 100, fit: BoxFit.cover)
                            : Image.file(File(msg["text"]), width: 100, height: 100, fit: BoxFit.cover))
                        : Text(
                            msg["text"]!,
                            style: const TextStyle(fontSize: 12, color: Colors.black87),
                          ),
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: Colors.grey.shade300)),
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.image, color: Colors.purple, size: 18),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: widget.onPickImage,
                ),
                const SizedBox(width: 4),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    onSubmitted: (value) {
                      if (value.trim().isNotEmpty) {
                        widget.onSend(value, false);
                        _controller.clear();
                      }
                    },
                    decoration: const InputDecoration(
                      hintText: "اكتب رسالة...",
                      hintStyle: TextStyle(fontSize: 11),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.purple, size: 16),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                  onPressed: () {
                    if (_controller.text.trim().isNotEmpty) {
                      widget.onSend(_controller.text, false);
                      _controller.clear();
                    }
                  },
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }
}