import 'package:flutter/material.dart';

// نموذج الموهبة المحدث
class TalentItem {
  final String id;
  final String name;
  final String category;
  final String description;
  final IconData icon;
  final Color themeColor;
  final String paymentMethod;
  final String transactionRef;
  int likesCount;
  bool isLiked;
  bool isApproved;
  final String email;
  final String password; // أضفنا حقل الباسورد

  TalentItem({
    required this.id,
    required this.name,
    required this.category,
    required this.description,
    required this.icon,
    required this.themeColor,
    this.paymentMethod = 'Vodafone Cash',
    this.transactionRef = '',
    this.likesCount = 0,
    this.isLiked = false,
    this.isApproved = false,
    this.email = '',
    this.password = '', // القيمة الافتراضية
  });

  // تحديث الخريطة لتشمل الباسورد
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'category': category,
      'description': description,
      'paymentMethod': paymentMethod,
      'transactionRef': transactionRef,
      'likesCount': likesCount,
      'isLiked': isLiked,
      'isApproved': isApproved,
      'email': email,
      'password': password, // حفظ الباسورد
    };
  }

  // تحديث من الفايربيس ليشمل الباسورد
  factory TalentItem.fromMap(Map<String, dynamic> map, String docId) {
    IconData defaultIcon = Icons.mic;
    Color defaultColor = Colors.deepPurple;
    
    if (map['category'] == 'poetry') {
      defaultIcon = Icons.history_edu;
      defaultColor = Colors.purple;
    } else if (map['category'] == 'composing') {
      defaultIcon = Icons.music_note;
      defaultColor = Colors.indigo;
    }

    return TalentItem(
      id: docId,
      name: map['name'] ?? '',
      category: map['category'] ?? 'singing',
      description: map['description'] ?? '',
      icon: defaultIcon,
      themeColor: defaultColor,
      paymentMethod: map['paymentMethod'] ?? 'Vodafone Cash',
      transactionRef: map['transactionRef'] ?? '',
      likesCount: map['likesCount'] ?? 0,
      isLiked: map['isLiked'] ?? false,
      isApproved: map['isApproved'] ?? false,
      email: map['email'] ?? '',
      password: map['password'] ?? '', // استرجاع الباسورد
    );
  }
}