import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'subscription_screen.dart';
import 'main_navigation_screen.dart';
import 'chat_radio_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  try {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyC0hhgt0mrzLN8d7dujnAcqmanAket4F24",
        authDomain: "sout-we-rouh.firebaseapp.com",
        projectId: "sout-we-rouh",
        storageBucket: "sout-we-rouh.firebasestorage.app",
        messagingSenderId: "250882692779",
        appId: "1:250882692779:web:36db079bd5ae62064549ee",
      ),
    );
  } catch (e) {
    debugPrint("Firebase initialization error: $e");
  }
  
  runApp(const SoutWeRouhApp());
}

class SoutWeRouhApp extends StatelessWidget {
  const SoutWeRouhApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'صوت وروح',
      debugShowCheckedModeBanner: false,
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child!,
        );
      },
      theme: ThemeData(
        primarySwatch: Colors.purple,
        scaffoldBackgroundColor: const Color(0xFF6A1B9A),
      ),
      home: const WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  void _showSmallMessage(BuildContext context, String message, {bool isError = true}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        backgroundColor: isError ? Colors.red.shade700 : Colors.green.shade700,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        margin: const EdgeInsets.symmetric(horizontal: 50, vertical: 20),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  void _showExternalLoginDialog(BuildContext context) {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController phoneController = TextEditingController();
    bool isLoading = false;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setStateDialog) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Text('دخول غرفة الشات والراديو 🎧', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          content: SizedBox(
            width: 280,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('اكتب بياناتك المسجلة للتحقق من الاشتراك ودخول الشات:', style: TextStyle(fontSize: 11, color: Colors.grey)),
                const SizedBox(height: 12),
                TextField(
                  controller: nameController,
                  decoration: InputDecoration(
                    hintText: 'اسمك الحقيقي...',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: phoneController,
                  decoration: InputDecoration(
                    hintText: 'رقم الهاتف المحول منه...',
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('إلغاء', style: TextStyle(color: Colors.grey)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7B1FA2)),
              onPressed: isLoading ? null : () async {
                String name = nameController.text.trim();
                String phone = phoneController.text.trim();

                if (name.isEmpty || phone.isEmpty) {
                  Navigator.pop(context);
                  _showSmallMessage(context, '⚠️ اكتب الاسم ورقم الهاتف المحول منه');
                  return;
                }

                setStateDialog(() { isLoading = true; });

                try {
                  var queryResult = await FirebaseFirestore.instance
                      .collection('talents')
                      .where('transactionRef', isEqualTo: phone)
                      .get();

                  setStateDialog(() { isLoading = false; });

                  if (queryResult.docs.isEmpty) {
                    Navigator.pop(context);
                    _showSmallMessage(context, '⚠️ رقم الهاتف المحول منه غير مسجل');
                    return;
                  }

                  var matchedDoc = queryResult.docs.first.data() as Map<String, dynamic>;
                  String dbName = matchedDoc['name'] ?? '';
                  bool isApproved = matchedDoc['isApproved'] ?? false;

                  if (dbName != name) {
                    Navigator.pop(context);
                    _showSmallMessage(context, '⚠️ الاسم غير مطابق لرقم الهاتف المحول منه');
                    return;
                  }

                  if (!isApproved) {
                    Navigator.pop(context);
                    _showSmallMessage(context, '⚠️ الحساب لم يتم تفعيله بعد');
                    return;
                  }

                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatRadioScreen(currentUserName: name),
                    ),
                  );

                } catch (e) {
                  setStateDialog(() { isLoading = false; });
                  Navigator.pop(context);
                  _showSmallMessage(context, '⚠️ حدث خطأ في الاتصال');
                }
              },
              child: isLoading 
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                  : const Text('دخول 🚀', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/logo.png',
                  width: 180,
                  height: 180,
                ),
                const SizedBox(height: 15),
                const Text(
                  'أهلاً بكم في تطبيق',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 18,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'صوت وروح ✨',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'منصتكم الأولى لاكتشاف ودعم أروع المواهب في الغناء، الشعر، والتلحين.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 14,
                  ),
                ),
                const SizedBox(height: 40),
                
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: const Color(0xFF6A1B9A),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const SubscriptionScreen(),
                        ),
                      );
                    },
                    child: const Text(
                      'تسجيل موهبة جديدة (مع الاشتراك)',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 15),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Colors.white, width: 1.5),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const MainNavigationScreen(),
                        ),
                      );
                    },
                    child: const Text(
                      'تصفح التطبيق مباشرة',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                const SizedBox(height: 15),

                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.tealAccent.shade700,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: () => _showExternalLoginDialog(context),
                    child: const Text(
                      '📻 استماع راديو نجوم إف إم والشات',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}